package com.spring;

import java.util.ArrayList;

public class EventList {

	ArrayList<Event> eventMenu = new ArrayList<>();
	
	public void insert(Event event) {
		//Fill your code here
	}
	public ArrayList<String> recommendfor(Double budget){
		//Fill your code here
	}

}
